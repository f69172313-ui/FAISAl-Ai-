import os
import streamlit as st
import pandas as pd
import numpy as np
import yfinance as yf
from pycoingecko import CoinGeckoAPI
from ta.momentum import RSIIndicator
from ta.trend import MACD
from ta.volatility import BollingerBands
from sklearn.preprocessing import MinMaxScaler
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM, Dense, Bidirectional

st.set_page_config(page_title="Ultimate AI Investment Bot", layout="wide")

# =========================
# Password config / fetch
# =========================
PASSWORD = None
try:
    PASSWORD = st.secrets["PASSWORD"]
except Exception:
    PASSWORD = os.environ.get("BOT_PASSWORD", None)

if PASSWORD is None:
    st.warning("পাসওয়ার্ড কনফিগ পাওয়া যায়নি। অনুগ্রহ করে .streamlit/secrets.toml বা BOT_PASSWORD সেট করুন।")

if "logged_in" not in st.session_state:
    st.session_state.logged_in = False
if "attempts" not in st.session_state:
    st.session_state.attempts = 0
MAX_ATTEMPTS = 5

def do_logout():
    st.session_state.logged_in = False

def check_password(pw):
    if PASSWORD is None:
        return False
    return pw == PASSWORD

if not st.session_state.logged_in:
    st.title("Login - Ultimate AI Investment Bot")
    pw = st.text_input("Enter password", type="password")
    if st.button("Login"):
        st.session_state.attempts += 1
        if st.session_state.attempts > MAX_ATTEMPTS:
            st.error("অনেকবার ভুল পাসওয়ার্ড দিয়েছেন — পরে আবার চেষ্টা করুন।")
        else:
            if check_password(pw):
                st.session_state.logged_in = True
                st.success("Login successful — স্বাগতম!")
                st.experimental_rerun()
            else:
                st.error(f"Password ভুল। চেষ্টা করেছেন: {st.session_state.attempts}/{MAX_ATTEMPTS}")
    st.stop()

st.sidebar.button("Logout", on_click=do_logout)
st.title("Ultimate AI Investment Bot - Multi Market (Protected)")

# ========================
# DATA PROCESSOR
# ========================
class DataProcessor:
    def __init__(self, ticker):
        self.ticker = ticker
        self.data = None

    def fetch_stock_data(self):
        df = yf.download(self.ticker, period='6mo', interval='1d')
        df.dropna(inplace=True)
        self.data = df
        return df

    def fetch_crypto_data(self, coin_id='bitcoin'):
        cg = CoinGeckoAPI()
        history = cg.get_coin_market_chart_by_id(id=coin_id, vs_currency='usd', days=180)
        prices = history['prices']
        df = pd.DataFrame(prices, columns=['Timestamp','Close'])
        df['Timestamp'] = pd.to_datetime(df['Timestamp'], unit='ms')
        df.set_index('Timestamp', inplace=True)
        df['Open'] = df['Close'].shift(1)
        df['High'] = df['Close'].rolling(3).max()
        df['Low'] = df['Close'].rolling(3).min()
        df['Volume'] = 0
        df.fillna(method='bfill', inplace=True)
        self.data = df
        return df

    def feature_engineering(self):
        df = self.data.copy()
        if 'Close' not in df.columns:
            raise ValueError("Data has no 'Close' column")
        df['RSI'] = RSIIndicator(df['Close'], window=14).rsi()
        macd = MACD(df['Close'])
        df['MACD'] = macd.macd()
        df['MACD_Signal'] = macd.macd_signal()
        bb = BollingerBands(df['Close'], window=20)
        df['BB_High'] = bb.bollinger_hband()
        df['BB_Low'] = bb.bollinger_lband()
        df.fillna(method='bfill', inplace=True)
        self.data = df
        return df

# ========================
# AI MODULE
# ========================
class AIModule:
    def __init__(self):
        self.model = None
        self.scaler = None

    def prepare_data(self, df):
        feature_cols = ['Close','RSI','MACD','MACD_Signal','BB_High','BB_Low']
        data = df[feature_cols]
        self.scaler = MinMaxScaler()
        scaled = self.scaler.fit_transform(data)
        X, y = [], []
        for i in range(30,len(scaled)):
            X.append(scaled[i-30:i])
            y.append(scaled[i,0])
        return np.array(X), np.array(y)

    def build_lstm(self, input_shape):
        model = Sequential()
        model.add(Bidirectional(LSTM(64, return_sequences=False), input_shape=input_shape))
        model.add(Dense(1))
        model.compile(optimizer='adam', loss='mse')
        self.model = model
        return model

    def train(self, X, y, epochs=3, batch_size=16):
        if X.size == 0:
            raise ValueError("Training data empty")
        self.model.fit(X, y, epochs=epochs, batch_size=batch_size, verbose=0)

    def predict_future(self, recent_data):
        feature_cols = ['Close','RSI','MACD','MACD_Signal','BB_High','BB_Low']
        scaled = self.scaler.transform(recent_data[feature_cols])
        X_input = np.expand_dims(scaled[-30:], axis=0)
        preds_scaled = self.model.predict(X_input, verbose=0)
        preds = self.scaler.inverse_transform(
            np.concatenate([preds_scaled, np.zeros((preds_scaled.shape[0],5))], axis=1)
        )[:,0]
        expected_change = (preds[-1]-recent_data['Close'].iloc[-1])/recent_data['Close'].iloc[-1]*100
        return expected_change

    def up_down_signal(self, predicted_change):
        return 'Up' if predicted_change>0 else 'Down'

# ========================
# App UI and logic
# ========================
tickers_input = st.text_input("Enter tickers / coins (comma separated)", "AAPL,BTC-USD")
trade_size = st.number_input("Trade Size ($)", min_value=1, value=1000)
if st.button("Analyse"):
    tickers_list = [t.strip() for t in tickers_input.split(',') if t.strip()]
    if not tickers_list:
        st.error("কমপক্ষে একটি টিকার দিন।")
    for ticker in tickers_list:
        st.subheader(ticker)
        dp = DataProcessor(ticker)
        try:
            if "USD" in ticker or len(ticker) > 5:
                coin_id = ticker.lower().replace('-usd','')
                df = dp.fetch_crypto_data(coin_id=coin_id)
            else:
                df = dp.fetch_stock_data()
        except Exception as e:
            st.error(f"Could not fetch data for {ticker}: {e}")
            continue

        try:
            df = dp.feature_engineering()
        except Exception as e:
            st.error(f"Feature engineering failed for {ticker}: {e}")
            continue

        st.line_chart(df['Close'])

        # AI
        ai = AIModule()
        try:
            X, y = ai.prepare_data(df)
            ai.build_lstm(X.shape[1:])
            ai.train(X, y)
            predicted_change = ai.predict_future(df)
            signal = ai.up_down_signal(predicted_change)
            st.write(f"Predicted Change: {predicted_change:.2f}% ({signal})")
            st.write(f"Trade Size: ${trade_size}")
        except Exception as e:
            st.warning(f"AI processing skipped for {ticker}: {e}")
